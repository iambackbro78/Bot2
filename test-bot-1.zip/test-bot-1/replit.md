# Discord Bot

## Overview

A feature-rich Discord bot built with discord.js v14, offering 400+ commands across multiple categories including moderation, music, economy, games, giveaways, leveling, tickets, and more. The bot uses MongoDB for data persistence and integrates with various external services for music playback, AI chat, and other features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Framework
- **Runtime**: Node.js with Express server on port 3000
- **Discord Library**: discord.js v14 with full gateway intents enabled
- **Entry Point**: `src/index.js` initializes Express and loads `src/bot.js` for Discord client setup

### Command Structure
Commands are organized by category in `src/commands/` with subdirectories:
- `afk/` - AFK status management
- `announcement/` - Server announcements
- `automod/` - Anti-spam, anti-invite, blacklist words
- `autosetup/` - Auto-create channels for features (tickets, logs, games)
- `birthdays/` - Birthday tracking
- `bot/` - Bot info, ping, uptime
- `casino/` - Gambling games (blackjack, slots, roulette)
- `config/` - Server configuration (welcome messages, levels, colors)
- `custom-commands/` - User-defined commands
- `developers/` - Admin/owner commands (eval, badges, bans)
- `economy/` - Virtual currency system with shop

### Database Layer
- **Database**: MongoDB via Mongoose
- **Connection**: `src/database/connect.js` handles connection with retry logic
- **Models**: Located in `src/database/models/` (referenced but not shown in files)
- **Schemas include**: economy, afk, birthday, blacklist, tickets, levels, invites, giveaways, custom commands, server settings

### Music System
- **Library**: erela.js with Lavalink
- **Plugins**: Spotify, Apple Music, Deezer, Facebook integrations
- **Voice**: @discordjs/voice for audio streaming

### Configuration
- `src/config/bot.js` - Bot settings (colors, prefix, invite links, AI prompt)
- `src/config/webhooks.json` - Webhook IDs/tokens for logging
- `src/config/emojis.json` - Custom emoji mappings
- Environment variables via dotenv for sensitive data

### Error Handling & Logging
- Webhook-based logging for errors, commands, DMs, voice events
- Process-level handlers for unhandledRejection and warnings
- Logs sent to Discord channels via WebhookClient

### Helper Utilities
- `src/assets/utils/` contains shared utilities (TriviaPlayer, time formatting, static defaults)
- Client methods for embeds, error messages, permission checks, money operations

## External Dependencies

### Required Services
- **MongoDB**: Primary database (requires `MONGO_TOKEN` env variable)
- **Discord Bot Token**: Required in environment variables
- **Lavalink Server**: Required for music playback (erela.js)

### Optional Integrations
- **Spotify API**: Music search via erela.js-spotify
- **Apple Music**: Music search via erela.js-apple
- **Deezer**: Music search via erela.js-deezer
- **Top.gg**: Bot listing and voting via @top-gg/sdk
- **Groq AI**: Chat functionality via groq-sdk
- **Google Translate**: Translation via @iamtraction/google-translate
- **Giphy**: GIF search via giphy-api

### Key NPM Packages
- `discord.js` ^14.8.0 - Discord API wrapper
- `mongoose` ^6.8.0 - MongoDB ODM
- `erela.js` ^2.4.0 - Music player
- `discord-giveaways` ^6.0.1 - Giveaway system
- `canvacord` ^6.0.2 - Image generation for rank cards
- `express` ^4.18.2 - Web server for health checks
- `axios` - HTTP requests
- `moment` / `moment-timezone` - Time handling

### Environment Variables Required
- `DISCORD_ID` - Bot client ID
- `MONGO_TOKEN` - MongoDB connection string
- `OWNER_ID` - Bot owner's Discord ID
- `WEBHOOK_ID` / `WEBHOOK_TOKEN` - Default webhook for logging